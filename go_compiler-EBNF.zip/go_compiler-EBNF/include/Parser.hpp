//
// Created by uberdever on 30.05.2020.
//

#ifndef GO_COMPILER_PARSER_HPP
#define GO_COMPILER_PARSER_HPP

#include "Lexan.hpp"
#include "AST.hpp"

class Parser
{
    Lexan* lexan;
    AST* ast;

    size_t curToken;
public:
    Parser(const string& filePath);

    void parse();

    void sourceFile();

    bool package(bool);
    bool import(bool);
    bool importSpec(bool);

    //bool topLvlDecl();
    //bool declaration();
    //bool funcDecl();
    //bool signature();
    //bool parameterList();
    //bool block();
    //bool identifierList();
    //bool type();

    bool concatenate(int fNum, ...);
    bool optional(bool alteration);
    bool repetition(bool alteration);

    bool alternation(int fNum, ...);
    bool tokenValid(const Token& token);

    bool tokenSemicolon(bool);
    bool tokenOpenParen(bool);
    bool tokenCloseParen(bool);
};

#endif //GO_COMPILER_PARSER_HPP
