//
// Created by uberdever on 30.05.2020.
//

#ifndef GO_COMPILER_LEXAN_HPP
#define GO_COMPILER_LEXAN_HPP

#include "Token.hpp"

enum class STATE
{
    DEFAULT,
    IDENTIFIER,
    OPERATOR,
    STRING,
    NUMBER
};

class Lexan
{
    static constexpr int OPERATOR_LEN = 10;
    static string tokenTypes[(int)TOKEN_TYPE::END + 1];

    static utility::hashT<uint32_t> keywords;
    static utility::hashT<uint32_t> operators;
    static vector<Token> tokenStream;

    string filePath;
    STATE curState = STATE::DEFAULT;
    uint32_t curToken {0};

    static void setupLexemes();
    static void pushToken (string& lex, TOKEN_TYPE type);

public:
    Lexan(const string& _filePath);
    void split();
    void print();

    Token& token();
    Token& peek();
    void next();
    void prev();

    void eat(Token const& token);
    bool match(Token const& token) const;
    void eatType(TOKEN_TYPE type);
    bool matchType(TOKEN_TYPE type) const;

    void semicolon();
    static bool search(string& str);
    bool isEmpty() const;
};

#endif //GO_COMPILER_LEXAN_HPP
