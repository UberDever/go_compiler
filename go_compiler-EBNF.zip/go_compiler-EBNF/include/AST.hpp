//
// Created by uberdever on 07.06.2020.
//

#ifndef GO_COMPILER_AST_HPP
#define GO_COMPILER_AST_HPP

#include "utility.hpp"

enum class NODE_TYPE
{

};

class node
{
    NODE_TYPE type;
    string name;
    list<node*> childNodes;

    void append(node* _node);
};

class AST
{
    node* head;

public:

    AST();
};

#endif //GO_COMPILER_AST_HPP
