//
// Created by uberdever on 07.06.2020.
//

#include "../include/AST.hpp"

void node::append(node* _node) {
    if (find(childNodes.begin(), childNodes.end(), _node) == childNodes.end() && _node != this)
    {
        childNodes.emplace_back(_node);
    }
}

AST::AST() : head{nullptr} {

}
