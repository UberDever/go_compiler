//
// Created by uberdever on 30.05.2020.
//

#include "../include/Parser.hpp"

Parser::Parser(const string& filePath) : curToken{0} {
    lexan = new Lexan(filePath);
    ast = new AST();
    lexan->split();
    lexan->print();
}

void Parser::parse() {
    std::cout << std::endl;
    std::cout << "BEGIN PARSING" << std::endl;
    Token arr[3] = {{",", TOKEN_TYPE::OPERATOR},
                    {"", TOKEN_TYPE::OPERATOR},
                    {"{", TOKEN_TYPE::OPERATOR}};
    sourceFile();
}

bool Parser::tokenValid(const Token &token) {
    return lexan->match(token);
}

bool Parser::alternation(int fNum, ...) {
    va_list args;
    va_list tmp;
    va_start(args, fNum);
    va_copy(tmp, args);

    bool (Parser::*f)(bool) = va_arg(tmp, bool (Parser::*)(bool));
    bool (Parser::*handle)(bool) = nullptr;
    bool bit = true;
    while (true)
    {
        va_end(tmp);
        va_copy(tmp, args);
        bit = false;
        for (int i = 0; i < fNum; i++)
        {
            if ((this->*f)(true))
            {
                bit = true;
                if (handle == nullptr)
                {
                    handle = f;
                } else
                {
                    handle = nullptr;
                    lexan->next();
                    break;
                }
            }
            f = va_arg(tmp, bool (Parser::*)(bool));
        }
        if (handle)
            break;
    }
    if (!bit) return false;

    (this->*f)(false);

    va_end(tmp);
    va_end(args);

    return true;
}

bool Parser::concatenate(int fNum, ...) {
    va_list args;
    va_start(args, fNum);

    bool (Parser::*f)(bool) = nullptr;
    bool isValid = true;
    for (int i = 0; i < fNum; i++)
    {
        f = va_arg(args, bool (Parser::*)(bool));
        isValid &= (this->*f)(false);
    }
    return isValid;
}

bool Parser::optional(bool alteration) {
    return alteration;
}

bool Parser::repetition(bool alteration) {
    while (optional(alteration));
    return false;
}

void Parser::sourceFile() {
    package(false);
    lexan->semicolon();
    repetition(alternation(1, &Parser::import));
    //while (topLvlDecl());
}

bool Parser::package(bool isCond) {
    if (isCond)
    {
        return lexan->match(Token("package", TOKEN_TYPE::KEYWORD));
    }
    lexan->eat(Token("package", TOKEN_TYPE::KEYWORD));

    string packageName = lexan->peek().lex;
    std::cout << packageName << std::endl; // TODO DO I REQUIRE THIS INFO?
    lexan->eatType(TOKEN_TYPE::IDENTIFIER);
}

bool Parser::import(bool isCond) {
    std::cout << "imports" << std::endl;
    if (isCond)
        return lexan->match(Token("import", TOKEN_TYPE::KEYWORD));

    lexan->next();
    //repetition(tokenOpenParen(true));
    //alternation(2,
    //        &Parser::importSpec,
    //        concatenate(3,
    //                &Parser::tokenOpenParen,
    //                repetition(concatenate(2,
    //                        &Parser::importSpec,
    //                        &Parser::tokenSemicolon)),
    //                &Parser::tokenCloseParen));

    //string importName = lexan->peek().lex;
    //std::cout << importName << std::endl; // TODO DO I REQUIRE THIS INFO?
    //lexan->eatType(TOKEN_TYPE::LITERAL);
//
    //lexan->semicolon();
    return true;
}

bool Parser::importSpec(bool) {
    return false;
}

bool Parser::tokenSemicolon(bool isCond) {
    return lexan->match(Token(";", TOKEN_TYPE::OPERATOR));
}

bool Parser::tokenOpenParen(bool) {
    return lexan->match(Token("(", TOKEN_TYPE::OPERATOR));
}

bool Parser::tokenCloseParen(bool) {
    return lexan->match(Token(")", TOKEN_TYPE::OPERATOR));
}

//bool Parser::topLvlDecl() {
//    return (declaration() || funcDecl());
//}
//
//bool Parser::funcDecl() {
//    if (!lexan->match(Token("func", TOKEN_TYPE::KEYWORD)))
//        return false;
//    lexan->next();
//    lexan->eatType(TOKEN_TYPE::IDENTIFIER);
//    signature();
//    block();
//    return true;
//}
//
//bool Parser::signature() {
//    lexan->eat(Token("(", TOKEN_TYPE::OPERATOR));
//    parameterList();
//    lexan->eat(Token(")", TOKEN_TYPE::OPERATOR));
//    return true;
//}
//
//bool Parser::identifierList() {
//    std::cout << lexan->peek().lex << std::endl; //TODO: Build AST
//    lexan->eatType(TOKEN_TYPE::IDENTIFIER);
//    while (!lexan->match(Token(",", TOKEN_TYPE::OPERATOR)))
//    {
//        lexan->next();
//        std::cout << lexan->peek().lex << std::endl;
//        lexan->eatType(TOKEN_TYPE::IDENTIFIER);
//    }
//    return true;
//}






