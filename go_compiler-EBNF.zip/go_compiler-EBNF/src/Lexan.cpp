//
// Created by uberdever on 30.05.2020.
//

#include "../include/Lexan.hpp"

string Lexan::tokenTypes[(int)TOKEN_TYPE::END + 1] = {"Identifier", "Keyword", "Operator", "Literal", "Number"};

utility::hashT<uint32_t> Lexan::keywords {101};
utility::hashT<uint32_t> Lexan::operators {101};
vector<Token> Lexan::tokenStream {};

void Lexan::split() {
    string lexeme;
    /*, tmpState;*/
    ifstream program{filePath};

    if (!program.is_open()) throw logic_error("Program file path incorrect");

    auto splitOperators = [&](string& lex)
    {
        stringstream ss{lex};
        string tmp;
        tmp.push_back(ss.peek());
        uint32_t* p = operators.search(tmp.c_str());
        if (!p) throw logic_error("Wrong operator " + lex);
        while (!ss.eof())
        {
            do
            {
                ss.get();
                tmp.push_back(ss.peek());
                p = operators.search(tmp.c_str());
            } while (p);
            tmp.pop_back();
            pushToken(tmp, TOKEN_TYPE::OPERATOR);
            tmp.push_back(ss.peek());
        }
        lex.clear();
    };

    while (!program.eof())
    {
        char sym = program.get();
        if (sym == -1) break;
        bool isOp = utility::isOperator(sym);
        bool isDel = utility::isDelimiter(sym);
        bool isNum = utility::isNumber(sym);
        bool isAlp = isalpha(sym) || sym == '_';
        bool isStr = sym == '"' || sym == '\'';
        bool isCom = sym == '/';

        auto changeState = [&]()
        {
            if (isAlp)
            {
                curState = STATE::IDENTIFIER;
                return ;
            }
            if (isdigit(sym))
            {
                curState = STATE::NUMBER;
                return ;
            }
            if (isOp)
            {
                curState = STATE::OPERATOR;
                return ;
            }
            if (isStr)
            {
                curState = STATE::STRING;
                return;
            }
            if (isDel)
            {
                curState = STATE::DEFAULT;
                return;
            }
            std::cout << sym << std::endl;
            throw logic_error("Incorrect symbol " + to_string(sym));
        };

        auto insertSemicolon = [&]()
        {
            if (sym == '\n')
            {
                string lex;
                lex.push_back(';');
                pushToken(lex, TOKEN_TYPE::OPERATOR);
            }
        };

        if (isCom)
        {
            if (program.peek() == '/')
            {
                char tmp = program.get();
                while (tmp != '\n') {
                    tmp = program.get();
                    if (tmp == -1)
                        throw logic_error("Line comment parse error!");
                };
                continue;
            }
            if (program.peek() == '*')
            {
                program.get();
                char tmp = program.get();
                while (tmp != '*') {
                    tmp = program.get();
                    if (tmp == -1)
                        throw logic_error("General comment parse error!");
                    if (program.peek() == '/')
                    {
                        program.get();
                        break;
                    }
                }
                continue;
            }
        }

        switch (curState) {
            case STATE::DEFAULT:
            {
                changeState();
                break;
            }
            case STATE::IDENTIFIER:
            {
                if (isDel || isOp)
                {
                    if (!lexeme.empty()) {
                        auto *p = keywords.search(lexeme.c_str());

                        if (p)
                        {
                            bool isSemicolon = lexeme == "break" || lexeme == "continue" || lexeme == "return" || lexeme == "fallthrough";
                            pushToken(lexeme, TOKEN_TYPE::KEYWORD);
                            if (isSemicolon) {
                                insertSemicolon();
                            }
                        }
                        else
                        {
                            pushToken(lexeme, TOKEN_TYPE::IDENTIFIER);
                            insertSemicolon();
                        }
                    }
                    curState = STATE::DEFAULT;
                    if (isOp)
                    {
                        curState = STATE::OPERATOR;
                        lexeme.push_back(sym);
                    }
                    continue;
                }
                if (isStr)
                    throw logic_error("Expected opening quotes: " + lexeme);
                break;
            }
            case STATE::OPERATOR:
            {
                if (isStr)
                {
                    pushToken(lexeme, TOKEN_TYPE::OPERATOR);
                    curState = STATE::STRING;
                    continue;
                }
                if (sym == '.')
                {
                    if (isdigit(program.peek()))
                    {
                        splitOperators(lexeme);
                        curState = STATE::NUMBER;
                        lexeme.push_back(sym);
                        continue;
                    }
                }
                if (!isOp)
                {
                    if (!lexeme.empty())
                    {
                        bool isSemicolon = lexeme == "++" || lexeme == "--" || lexeme == "]" || lexeme == ")" || lexeme == "}";
                        splitOperators(lexeme);
                        if (isSemicolon)
                            insertSemicolon();

                    }
                    changeState();
                }
                break;
            }
            case STATE::NUMBER:
            {
                if (!isNum)
                {
                    if (!lexeme.empty()) {
                        pushToken(lexeme, TOKEN_TYPE::NUMBER);
                    }
                    insertSemicolon();
                    changeState();
                }
                break;
            }
            case STATE::STRING:
            {
                if (sym == '\n' || sym == -1)
                    throw logic_error("Expected closing quotes: " + lexeme);
                if (isStr)
                {
                    pushToken(lexeme, TOKEN_TYPE::LITERAL);
                    sym = program.peek();
                    insertSemicolon();
                    curState = STATE::DEFAULT;
                    continue;
                }
                lexeme.push_back(sym);
                continue;
            }
        }
        if (!isDel && !isStr)
            lexeme.push_back(sym);
    }
    //auto *p = operators.search(lexeme.c_str());
}

Lexan::Lexan(const string &_filePath) {
    setupLexemes();

    filePath = _filePath;
}

void Lexan::pushToken(string &lex, TOKEN_TYPE type) {
    switch (type) {
        case TOKEN_TYPE::NUMBER:
        {
            if (lex[0] == '0')
            {
                for (int i = 1; i < lex.length(); i++)
                {
                    if (!utility::isNumber(lex[i])) throw logic_error("Wrong number format: " + lex);
                }
            } else
            {
                for (int i = 1; i < lex.length(); i++)
                {
                    if (!isdigit(lex[i]) && lex[i] != '.') throw logic_error("Wrong number format: " + lex);
                }
            }
            break;
        }
        default:break;
    }
    tokenStream.emplace_back(lex, type);
    lex.clear();
}

void Lexan::setupLexemes() {
    ifstream inOp(utility::CFG_OPERATORS_PATH);

    if (!inOp.is_open()) throw logic_error("Operators file doesn't open");

    char sym;
    string tmp;

    while (!inOp.eof())
    {
        sym = inOp.get();
        if (utility::isDelimiter(sym) || !sym || sym == -1)
        {
            if (!tmp.empty())
            {
                operators[tmp.c_str()] = utility::hash(tmp.c_str(), strlen(tmp.data()));
                //std::cout << "op: " << tmp.c_str() << std::endl;
            }
            tmp.clear();
        } else {
            tmp.push_back(sym);
        }
    }

    ifstream inKw(utility::CFG_KEYWORDS_PATH);
    tmp.clear();

    if (!inKw.is_open()) throw logic_error("Keywords file doesn't open");

    while (!inKw.eof())
    {
        sym = inKw.get();
        if (utility::isDelimiter(sym) || !sym || sym == -1)
        {
            if (!tmp.empty())
            {
                keywords[tmp.c_str()] = utility::hash(tmp.c_str(), strlen(tmp.data()));
            }
            tmp.clear();
        } else {
            tmp.push_back(sym);
        }
    }

    //for (int i = 0; i < operators.size(); i++)
        //std::cout << operators[i] << std::endl;

    //throw logic_error("error");
}

void Lexan::print() {
    for (auto & i : tokenStream) {
        std::cout << i.lex << " (" << tokenTypes[(int)i.type] << ")" << std::endl;
    }
}

Token &Lexan::token() {
    auto& tmp = peek();
    next();
    return tmp;
}

Token &Lexan::peek() {
    static Token voidToken("");
    if (isEmpty())
        return voidToken;
    return tokenStream[curToken];
}

void Lexan::next() {
    curToken++;
}

bool Lexan::match(const Token &token) const{
    return (token.type == tokenStream[curToken].type && token.lex == tokenStream[curToken].lex);
}

void Lexan::eat(Token const& token) {
    if (!match(token))
        throw logic_error("Wrong token: " + tokenStream[curToken].lex + " (" + tokenTypes[(int)tokenStream[curToken].type]
                          + "), expected " + token.lex + " (" + tokenTypes[(int)token.type] + ")");
    next();
}

bool Lexan::matchType(TOKEN_TYPE type) const {
    static string tokenTypes[(int)TOKEN_TYPE::END + 1] = {"Identifier", "Keyword", "Operator", "Literal", "Number"};

    return (type == tokenStream[curToken].type);

}

void Lexan::eatType(TOKEN_TYPE type) {
    if (!matchType(type))
        throw logic_error("Wrong token: " + tokenStream[curToken].lex + " (" + tokenTypes[(int)tokenStream[curToken].type]
                          + "), expected (" + tokenTypes[(int)type] + ")");
    next();
}

bool Lexan::search(string &str) {
    return keywords.search(str.c_str());
}

bool Lexan::isEmpty() const {
    return curToken >= tokenStream.size();
}

void Lexan::semicolon() {
    eat(Token(";", TOKEN_TYPE::OPERATOR));
}

void Lexan::prev() {
    if (curToken > 0) curToken--;
}

