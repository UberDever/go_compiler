//
// Created by uberdever on 30.05.2020.
//

#include "../include/Compiler.hpp"

int Compiler::compile() {
    parser->parse();
    return 0;
}

Compiler::Compiler(int argc, char* argv[]) {
    //filePath = ;
    //std::cout << "path: " << argv[argc - 1] << std::endl;
    parser = new Parser("test.go");
}

