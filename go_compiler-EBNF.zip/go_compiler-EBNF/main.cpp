#include <iostream>
#include "./include/Compiler.hpp"

int main(int argc, char* argv[]) {
    auto* c = new Compiler(argc, argv);
    return c->compile();
}
